package Controllers;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

import Models.Bank;

public class BanksManager {
    private HashMap<Integer, Bank> banks;
    private ReentrantLock lock;
    private static BanksManager instance;

    private BanksManager(){
        lock = new ReentrantLock();
        banks = new HashMap<>();
    }

    public static BanksManager getInstance(){
        if(instance == null){
            synchronized(BanksManager.class){
                if(instance == null){
                    instance = new BanksManager();
                    return instance;
                }
            }
        }

        return instance;
    }

    public void AddBank(Bank bank){
        lock.lock();
        banks.put(bank.getId(), bank);
        lock.unlock();
    }

    public void RemoveBank(Bank bank){
        lock.lock();
        if(banks.containsKey(bank.getId())){
            banks.remove(bank.getId());
        }
        lock.unlock();
    }

    public void ShowBanks(){
        lock.lock();
         banks.forEach((id, bank) -> {
            System.out.println("Bank ID: " + id + ", Bank Name: " + bank.getName());
        });
        lock.unlock();
    }
}
