package Controllers;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

import Models.Client;

public class ClientsManager {
    private HashMap<Integer, Client> clients;
    private ReentrantLock lock;
    private static ClientsManager instance;

    // Private constructor for Singleton Pattern
    private ClientsManager() {
        lock = new ReentrantLock();
        clients = new HashMap<>();
    }

    // Get Singleton Instance (Double-Checked Locking for Thread Safety)
    public static ClientsManager getInstance() {
        if (instance == null) {
            synchronized (ClientsManager.class) {
                if (instance == null) {
                    instance = new ClientsManager();
                }
            }
        }
        return instance;
    }

    // Add a new client
    public void AddClient(Client client) {
        lock.lock();
        try {
            clients.put(client.getId(), client);
        } finally {
            lock.unlock();
        }
    }

    // Remove a client
    public void RemoveClient(Client client) {
        lock.lock();
        try {
            if (clients.containsKey(client.getId())) {
                clients.remove(client.getId());
            }
        } finally {
            lock.unlock();
        }
    }

    // Display all clients
    public void ShowClients() {
        lock.lock();
        try {
            clients.forEach((id, client) -> {
                System.out.println("Client ID: " + id + ", Client Name: " + client.getName());
            });
        } finally {
            lock.unlock();
        }
    }
}
