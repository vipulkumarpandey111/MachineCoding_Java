package Controllers;

import Models.Client;
import Models.Transaction;

import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;

import Models.Bank;

public class PaymentGatewayManager {
    private ClientsManager clientsManager;
    private BanksManager banksManager;
    private TransactionsManager transactionsManager;
    private PaymentTypeManager paymentTypeManager;

    private ReentrantLock lock;
    private static PaymentGatewayManager instance;

    private PaymentGatewayManager(){
        lock = new ReentrantLock();
        paymentTypeManager = PaymentTypeManager.getInstance();
        transactionsManager = TransactionsManager.getInstance();
        banksManager = BanksManager.getInstance();
        clientsManager = ClientsManager.getInstance();
    }

    public static PaymentGatewayManager getInstance(){
        if(instance == null){
            synchronized(PaymentGatewayManager.class){
                if(instance == null){
                    instance = new PaymentGatewayManager();
                    return instance;
                }
            }
        }

        return instance;
    }

    public void AddClients(){
        Client client1 = new Client("Flipkart", 1);
        Client client2 = new Client("Amazon", 2);
        clientsManager.AddClient(client1);
        clientsManager.AddClient(client2);
    }

    public void AddBanks(){
        Bank bank1 = new Bank("HDFC", 1);
        Bank bank2 = new Bank("ICICI", 2);
        banksManager.AddBank(bank1);
        banksManager.AddBank(bank2);
    }

    public void CreateTransaction(Scanner sc){
        try{
            lock.lock();
            System.out.println("Add Transaction Details : Id, Type, Amount, Time");
            Transaction transaction = new Transaction(sc.nextInt(), sc.nextInt(), sc.nextInt(), sc.nextLine());
            transaction.RouteToBank(transaction.PaymentType);
            System.out.println("Add Payment Type : \n");
            paymentTypeManager.AddPaymentType(sc.nextInt(), sc);
            transaction.setStatus();
            transactionsManager.AddTransaction(transaction);
            transactionsManager.ShowTransactions();
        }
        catch(Exception e){
            System.out.println("Error in Creating Transaction : "  + e.getMessage());
        }
        finally{
            lock.unlock();
        }
    }

    public void RunApplication(Scanner sc){
        try{
            boolean exit = false;
            while (!exit) {
                System.out.println("\n----- Payment Gateway Menu -----");
                System.out.println("1. Add Bank");
                System.out.println("2. Add Client");
                System.out.println("3. Add Transaction");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                String choice = sc.nextLine();
                
                switch (choice) {
                    case "1":
                        AddBanks();
                        break;
                    case "2":
                        AddClients();
                        break;
                    case "3":
                        CreateTransaction(sc);
                        break;
                    case "4":
                        exit = true;
                        System.out.println("Exiting Payment Gateway. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }
        catch(Exception e){
            System.out.println("Command Input Error : " + e.getMessage());
        }
    }
}
