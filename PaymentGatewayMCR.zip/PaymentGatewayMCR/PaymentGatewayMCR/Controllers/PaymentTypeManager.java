package Controllers;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

import Models.PaymentCategory;
import Models.PaymentCategoryCards;
import Models.PaymentCategoryNetBanking;
import Models.PaymentCategoryUpi;

public class PaymentTypeManager {
    private ReentrantLock lock;
    private static PaymentTypeManager instance;

    private PaymentTypeManager(){
        lock = new ReentrantLock();
    }

    public static PaymentTypeManager getInstance(){
        if(instance == null){
            synchronized(PaymentTypeManager.class){
                if(instance == null){
                    instance = new PaymentTypeManager();
                    return instance;
                }
            }
        }

        return instance;
    }

    public void AddPaymentType(int paymentType, Scanner sc){
        System.out.println("Add Payment type and credentials!");
        PaymentCategory type;
        try{
            lock.lock();
            switch (paymentType) {
                case 0:
                    type = new PaymentCategoryCards();
                    SetPaymentCredentials(3, type, sc);
                    break;
                case 1:
                    type = new PaymentCategoryUpi();
                    SetPaymentCredentials(1, type, sc);
                    break;
                case 2:
                    type = new PaymentCategoryNetBanking();
                    SetPaymentCredentials(2, type, sc);
                    break;
                
                default:
                    throw new Exception("Invalid Payment Type");
            }
        }
        catch(Exception e){
            System.out.println("Invalid Payment Type");
        }
        finally{
            lock.unlock();
        }
    }

    public void SetPaymentCredentials(int countParams, PaymentCategory type, Scanner sc){
        if(sc.hasNextLine()){
            sc.nextLine();
        }
        ArrayList<Object> params = new ArrayList<>();
        while (countParams > 0) {
            System.out.println("Add credentials!");
            params.add(sc.nextLine());
            countParams--;
        }

        type.SetCredentials(params);
        type.ValidateCredentials();
    }
}
