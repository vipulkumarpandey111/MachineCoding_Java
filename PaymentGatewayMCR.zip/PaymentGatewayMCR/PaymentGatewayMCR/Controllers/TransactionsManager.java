package Controllers;

import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;

import Models.Transaction;

public class TransactionsManager {
    private HashMap<Integer, Transaction> transactions;
    private ReentrantLock lock;
    private static TransactionsManager instance;

    // Private constructor for Singleton Pattern
    private TransactionsManager() {
        lock = new ReentrantLock();
        transactions = new HashMap<>();
    }

    // Get Singleton Instance (Double-Checked Locking for Thread Safety)
    public static TransactionsManager getInstance() {
        if (instance == null) {
            synchronized (TransactionsManager.class) {
                if (instance == null) {
                    instance = new TransactionsManager();
                }
            }
        }
        return instance;
    }

    // Add a new transaction
    public void AddTransaction(Transaction transaction) {
        lock.lock();
        try {
            transactions.put(transaction.Id, transaction);
        } finally {
            lock.unlock();
        }
    }

    // Remove a transaction by ID
    public void RemoveTransaction(int transactionId) {
        lock.lock();
        try {
            if (transactions.containsKey(transactionId)) {
                transactions.remove(transactionId);
            }
        } finally {
            lock.unlock();
        }
    }

    // Get a transaction by ID
    public Transaction GetTransaction(int transactionId) {
        lock.lock();
        try {
            return transactions.getOrDefault(transactionId, null);
        } finally {
            lock.unlock();
        }
    }

    // Display all transactions
    public void ShowTransactions() {
        lock.lock();
        try {
            transactions.forEach((id, transaction) -> {
                System.out.println("Transaction ID: " + id + ", Amount: " + transaction.amount + ", Status: " + transaction.status);
            });
        } finally {
            lock.unlock();
        }
    }
}
