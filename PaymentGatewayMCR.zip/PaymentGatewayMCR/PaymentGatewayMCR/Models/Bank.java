package Models;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

public class Bank {
    private String Name;
    private int Id;
    public ArrayList<Integer> PaymentTypes;
    public HashMap<Integer, Transaction> transactionsList;
    private ReentrantLock lock;

    public Bank(String name, int id) {
        Name = name;
        Id = id;
        PaymentTypes = new ArrayList<Integer>();
        transactionsList = new HashMap<>();
        lock = new ReentrantLock();
    }

    public String getName() {
        return Name;
    }
    
    public void setName(String name) {
        Name = name;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getId() {
        return Id;
    }

    public Transaction ReturnTransaction(Integer id){
        lock.lock();
        try{
            {
                if(transactionsList.containsKey(id)){
                    return transactionsList.get(id);
                }
                else{
                    throw new Exception("Transaction not present!");
                }
            }
        }
        catch(Exception e){
            System.out.println("Invalid Transaction");
            return null;
        }
        finally{
            lock.unlock();
        }
    }
}
