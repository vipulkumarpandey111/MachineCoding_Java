package Models;

import java.util.ArrayList;

public class Client {
    private String Name;
    private int Id;
    public ArrayList<Integer> PaymentTypes;

    public Client(String name, int id) {
        Name = name;
        Id = id;
        PaymentTypes = new ArrayList<Integer>();
    }

    public String getName() {
        return Name;
    }
    
    public void setName(String name) {
        Name = name;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getId() {
        return Id;
    }
}
