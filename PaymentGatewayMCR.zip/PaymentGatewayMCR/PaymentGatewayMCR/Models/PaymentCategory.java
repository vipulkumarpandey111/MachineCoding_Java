package Models;

public interface PaymentCategory {

    public abstract void SetCredentials(Object... params);

    public abstract boolean ValidateCredentials();
}