package Models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PaymentCategoryCards implements PaymentCategory{
    private String cardNumber;
    private Date expiryDate;
    private int cvv;

    @Override
    public void SetCredentials(Object... params) {
        try {
            this.cardNumber = params[0].toString();
            this.expiryDate = new SimpleDateFormat("MM/yy").parse(params[1].toString());
            this.cvv = Integer.parseInt(params[2].toString());
        } catch (ParseException | NumberFormatException e) {
            System.out.println("Invalid input format: " + e.getMessage());
        }
    }

    @Override
    public boolean ValidateCredentials() {
        return true;
    }
}
