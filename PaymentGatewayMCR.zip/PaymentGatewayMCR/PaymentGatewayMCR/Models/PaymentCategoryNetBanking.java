package Models;

public class PaymentCategoryNetBanking implements PaymentCategory{
    private String username;
    private String password;

    @Override
    public void SetCredentials(Object... params) {
        this.username = params[0].toString();
        this.password = params[1].toString();
    }

    @Override
    public boolean ValidateCredentials() {
        return true;
    }
}
