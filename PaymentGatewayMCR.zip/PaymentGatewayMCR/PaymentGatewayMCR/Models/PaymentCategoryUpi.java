package Models;

public class PaymentCategoryUpi implements PaymentCategory{
    private String UpiId;

    @Override
    public void SetCredentials(Object... params){
        this.UpiId = params[0].toString();
    }

    @Override
    public boolean ValidateCredentials(){
        return true;
    }
}
