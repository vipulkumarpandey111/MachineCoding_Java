package Models;

public enum PaymentType{
    Card,
    UPI,
    NetBanking
}