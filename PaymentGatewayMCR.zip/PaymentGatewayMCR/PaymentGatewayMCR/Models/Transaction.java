package Models;

public class Transaction {
    public int Id;
    public Integer PaymentType;
    public Bank bank;
    public int amount;
    public String time;
    public boolean status;

    public Transaction(int id, int paymentType, int amount, String time) {
        Id = id;
        PaymentType = paymentType;
        this.amount = amount;
        this.time = time;
    }

    public void RouteToBank(int category){
        //ToDo : Route using payment category
        this.bank = new Bank("HDFC", 1);
    }

    public void setStatus(){
        //ToDo : set Randomly
        this.status = true;
    }
}
