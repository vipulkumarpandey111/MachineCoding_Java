import java.util.*;

import Controllers.PaymentGatewayManager;

public class PaymentGateway{
    private static PaymentGatewayManager paymentGatewayManager;

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String gatwayName = sc.nextLine();
        System.out.println("Welcome to " + gatwayName);
        paymentGatewayManager = PaymentGatewayManager.getInstance();
        paymentGatewayManager.RunApplication(sc);
        sc.close();
    }
}